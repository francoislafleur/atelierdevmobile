# Notes F7

Exemple d'app mobile Cordova/F7

Utilisation de l'API HTML5 localStorage

# utilisation

Télécharger et dézipper (étape 1 dans branche Step1, étape 2 dans branche Step2,... état actuel dans branche master)

## branche step1
Ajout possible de notes et sauvegarde dans localStorage
